$(document).ready(function () {    

    $('#login_form').validate({ 
        rules: {
            location_name: {
                required: true
            },
            location_password: {
                required: true
            }
        },
        messages :{
            location_name : {  
                required : '<small class="text-danger">Please Select Location</small>'
            },
            location_password : {
                required : '<small class="text-danger">Please Enter Password</small>'
            }
        },
        errorPlacement: function (error, element) {
            
            if(element.attr("name") == "location_name") 
            {
                error.appendTo("#location_name_error");
            }
            else 
            {
                error.insertAfter(element)
            }
        }
    });

    $('#profile_form').validate({ 
        rules: {
            location_name: {
                required: true
            },
            location_tax: {
                required: true
            },
            location_password: {
                required: true
            }
        },
        messages :{
            location_name : {
                required : '<small class="text-danger">Please Enter Location</small>'
            },
            location_tax : {
                required : '<small class="text-danger">Please Enter Tax</small>'
            },
            location_password : {
                required : '<small class="text-danger">Please Enter Password</small>'
            }
        }
    });

});