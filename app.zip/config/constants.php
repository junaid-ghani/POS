<?php

return [

    'site_title' => 'POS System',
    'admin_path' => 'assets/admin/',
    'mail_from' => 'admin@codetrickz.com',
    'mail_to' => 'webdeveloper030303@gmail.com',

];