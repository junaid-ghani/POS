<link rel="shortcut icon" type="image/x-icon" href="{{ asset(config('constants.admin_path').'img/favicon.png') }}">
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'css/bootstrap.min.css') }}">
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'css/bootstrap-datetimepicker.min.css') }}">
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'css/animate.css') }}">
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'css/feather.css') }}">
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'plugins/select2/css/select2.min.css') }}">
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'plugins/owlcarousel/owl.carousel.min.css') }}">
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'plugins/summernote/summernote-bs4.min.css') }}">
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'plugins/bootstrap-tagsinput/bootstrap-tagsinput.css') }}">
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'css/dataTables.bootstrap5.min.css') }}">
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'plugins/fontawesome/css/fontawesome.min.css') }}">
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'plugins/fontawesome/css/all.min.css') }}">
<link rel="stylesheet" href="{{ asset(config('constants.admin_path').'css/style.css') }}">