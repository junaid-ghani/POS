<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="submenu-open">
                    <ul>
                        <li><a href="{{ route('admin.dashboard') }}" @if(isset($set) && $set == 'dashboard') class="active" @endif><i data-feather="box"></i><span>Dashboard</span></a></li>
                        <li class="submenu">
                            <a href="javascript:void(0);" class="subdrop @if(isset($set) && ($set == 'sales' || $set == 'create_sale')) active @endif"><i data-feather="shopping-cart"></i><span>Sales</span><span class="menu-arrow"></span></a>
                            <ul>
                                <li><a href="{{ route('admin.search_location') }}" @if(isset($set) && $set == 'create_sale') class="active" @endif>Create Sale</a></li>
                                <li><a href="{{ route('admin.sales') }}" @if(isset($set) && $set == 'sales') class="active" @endif>Manage Sales</a></li>
                            </ul>
                        </li>
                        <li class="submenu">
                            <a href="javascript:void(0);" class="subdrop @if(isset($set) && ($set == 'assign_products' || $set == 'transfer_products' || $set == 'stocks')) active @endif"><i data-feather="package"></i><span>Inventory</span><span class="menu-arrow"></span></a>
                            <ul>
                                
                                <li><a href="{{ route('admin.stocks') }}" @if(isset($set) && $set == 'stocks') class="active" @endif>Manage Inventory</a></li>
                                <li><a href="{{ route('admin.transfer_products') }}" @if(isset($set) && $set == 'transfer_products') class="active" @endif>Transfers</a></li>
                                <li><a href="{{ route('admin.assign_products') }}" @if(isset($set) && $set == 'assign_products') class="active" @endif>Assign Products</a></li>
                            </ul>
                        </li>
                        <li><a href="{{ route('admin.products') }}" @if(isset($set) && $set == 'products') class="active" @endif><i data-feather="box"></i><span>Products</span></a></li>
                        <li><a href="{{ route('admin.category') }}" @if(isset($set) && $set == 'category') class="active" @endif><i data-feather="codepen"></i><span>Categories</span></a></li>
                        <li><a href="{{ route('admin.customers') }}" @if(isset($set) && $set == 'customers') class="active" @endif><i data-feather="user"></i><span>Customers</span></a></li>
                        <li><a href="{{ route('admin.locations') }}" @if(isset($set) && $set == 'locations') class="active" @endif><i data-feather="home"></i><span>Locations</span></a></li>
                        <li><a href="{{ route('admin.users') }}" @if(isset($set) && $set == 'users') class="active" @endif><i data-feather="users"></i><span>Users</span></a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>