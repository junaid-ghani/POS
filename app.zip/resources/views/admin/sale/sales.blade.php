@extends('admin.layouts.app')
@section('title', config('constants.site_title') . ' | Sales')
@section('contents')
    <div class="content">
        <div class="page-header">
            <div class="add-item d-flex">
                <div class="page-title">
                    <h4>Sales</h4>
                    <h6>Manage Sales</h6>
                </div>
            </div>
            <ul class="table-top-head">
                <li>
                    <a href="{{ route('admin.sales') }}" data-bs-toggle="tooltip" data-bs-placement="top" title="Refresh"><i
                            data-feather="rotate-ccw" class="feather-rotate-ccw"></i></a>
                </li>
                <li>
                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i
                            data-feather="chevron-up" class="feather-chevron-up"></i></a>
                </li>
            </ul>
        </div>
        <div class="card table-list-card">
            <div class="card-body">
                <div class="table-top">
                    
                    <div class="search-set">
                        <div class="search-input">
                            <a href="javascript:void(0);" class="btn btn-searchset"><i data-feather="search" class="feather-search"></i></a>
                        </div>
                    </div>
                    
                    
                    <div class="card mb-0" id="filter_inputs" style="display:block; width: 520px;">
                        <div class="card-body pb-0">
                            
                            <div class="row">
                                <div class="col-lg-5 col-sm-6 col-12">
                                    <div class="input-blocks  mb-0">
                                        <i data-feather="home" class="info-img"></i>
                                        <select name="location_id" id="location_id" class="form-control selectbox_location" onchange="filter_options()">
                                            
                                            <!--<option value="" > Location</option>-->
                                            <option selected value="all"> All Locations</option>
                                            @foreach ($locations as $location)
                                                <option value="{{ $location->location_id }}"> {{ $location->location_name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <!--<div class="col-lg-2 col-sm-6 col-12">-->
                                <!--    <div class="input-blocks">-->
                                <!--        <i data-feather="calendar" class="info-img"></i>-->
                                <!--        <div class="input-groupicon">-->
                                <!--            <input type="text" id="start_date" class="datetimepicker"-->
                                <!--                placeholder="Start Date">-->
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--</div>-->
                                <!--<div class="col-lg-2 col-sm-6 col-12">-->
                                <!--    <div class="input-blocks">-->
                                <!--        <i data-feather="calendar" class="info-img"></i>-->
                                <!--        <div class="input-groupicon">-->
                                <!--            <input type="text" id="end_date" class="datetimepicker"-->
                                <!--                placeholder="End Date">-->
                                <!--        </div>-->
                                <!--    </div>-->
                                <!--</div>-->
        
                                <div class="col-lg-7 col-sm-6 col-12">
                                    <div id="reportrange" style=" cursor: pointer; padding: 8.5px 10px; border: 1px solid #dbe0e6; width: 100%; color:#5B6670; border-radius:5px;">
                                        <i class="fa fa-calendar"></i>&nbsp;
                                        <span></span> <i class="fa fa-caret-down"></i>
                                    </div>
                                </div> 
                                
                      
                                <input type="hidden" value="{{ $today }}" id="ini_start_date" >
                                <input type="hidden" value="{{ $today }}" id="ini_end_date" >
                                
                            </div>              
                               
                        </div>
                    </div>
                </div>
                

               


                <div class="table-responsive">
                    <table id="sale_table" class="table" style="width: 100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Invoice No</th>
                                <th>Date</th>
                                <!--<th>Customer</th>-->
                                <th>Location</th>
                                <th>Sellers</th>
                                <th>Sub Total ($)</th>
                                <th>Tax ($)</th>
                                <th>Total ($)</th>
                                <!--<th>Created By</th>-->
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>


                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('custom_script')


<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css"
    href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

<script type="text/javascript">

//  ------ datepicker -----

        $(function () {

            var start = moment();
            var end = moment();

            function cb(start, end) {
                $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
            }

            $('#reportrange').daterangepicker({
                startDate: start,
                endDate: end,
                ranges: {
                    'Today': [moment(), moment()],
                    'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                    'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                    'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                    'This Month': [moment().startOf('month'), moment().endOf('month')],
                    'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
                }
            }, cb);

            cb(start, end);

            $('#reportrange').on('apply.daterangepicker', function (ev, picker) {
                let start_date = picker.startDate.format('YYYY-MM-DD');
                let end_date = picker.endDate.format('YYYY-MM-DD');
                
                $('#ini_start_date').prop("value", start_date); 
                $('#ini_end_date').prop("value",end_date); 
                dataTable.draw();
            });
        });

//   datepicker end


        var dataTable = $('#sale_table').DataTable({
            
            "bFilter": true,
            "sDom": 'fBtlpi',
            "ordering": true,
            "language": {
                search: ' ',
                sLengthMenu: '_MENU_',
                searchPlaceholder: "Search",
                info: "_START_ - _END_ of _TOTAL_ items",
                paginate: {
                    next: ' <i class=" fa fa-angle-right"></i>',
                    previous: '<i class="fa fa-angle-left"></i> '
                },
            },
            initComplete: (settings, json) => {
                $('.dataTables_filter').appendTo('#tableSearch');
                $('.dataTables_filter').appendTo('.search-input');
            },
            processing: true,
            serverSide: true,
            
            'ajax': {
                type: 'POST',
                url: "{{ route('admin.get_sales') }}",
                'data': function(data) {

                    var token = "{{ csrf_token() }}";
                    var location_id = $('#location_id').val();
                    var start_date = $('#ini_start_date').val();
                    var end_date = $('#ini_end_date').val();

                    data._token = token;
                    // data.location_id = location_id;
                    data.location_id = (location_id === "all") ? null : location_id;
                    data.start_date = start_date;
                    data.end_date = end_date;
                }
            },
            columns: [{
                    data: 'DT_RowIndex'
                },
                {
                    data: 'sale_invoice_no'
                },
                {
                    data: 'sale_date'
                },
                // {data: 'customer_name'},
                {
                    data: 'location_name'
                },
                {
                    data: 'sellers'
                },
                {
                    data: 'sale_sub_total'
                },
                {
                    data: 'sale_tax_amount'
                },
                {
                    data: 'sale_grand_total'
                },
                // {data: 'user_name'},
                {
                    data: 'action',
                    orderable: false,
                    searchable: false
                }
            ]
        });

        function filter_options() {
            dataTable.draw();
        }

        $('#start_date').on('dp.change', function(e) {
            filter_options();
        })
        $('#end_date').on('dp.change', function(e) {
            filter_options();
        })

        $(".selectbox_location").select2({
            placeholder: "All Location"
        });

        function confirm_msg(ev) {
            ev.preventDefault();

            var urlToRedirect = ev.currentTarget.getAttribute('href');

            Swal.fire({
                title: "Are you sure?",
                text: "You want to change status!",
                type: "warning",
                showCancelButton: !0,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Yes, change it!",
                confirmButtonClass: "btn btn-success",
                cancelButtonClass: "btn btn-danger ml-1",
                buttonsStyling: !1,
                icon: "warning",
            }).then(function(t) {

                if (t.value) {
                    window.location.href = urlToRedirect;
                }
            });
        }
    </script>
@endsection
