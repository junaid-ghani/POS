<div class="table-list-card">
    <div class="table-top">
        <div class="search-set">
            <div class="search-input">
                <a href="javascript:void(0);" class="btn btn-searchset"><i data-feather="search" class="feather-search"></i></a>
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table id="product_table" class="table" style="width: 100%">
            <thead>
                <tr>
                    <th>Select</th>
                    <th>Product</th>
                    <th>Code</th>
                    <th>Stock</th>
                    <th>Quantity</th>
                </tr>
            </thead>
            <tbody>
                @foreach($products as $product)
                <tr>
                    <td>
                        <input type="checkbox" name="transfer_products[{{ $product->product_id }}]" value="{{ $product->product_id }}">
                    </td>
                    <td>{{ $product->product_name }}</td>
                    <td>{{ $product->product_code }}</td>
                    <td>{{ $product->stock_quantity }}</td>
                    <td>
                        <input type="number" class="form-control" name="transfer_quantity[{{ $product->product_id }}]" autocomplete="off">
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
<script>
$('#product_table').DataTable({
    "bFilter": true,
    "sDom": 'fBtlpi',
    "ordering": true,
    "language": {
        search: ' ',
        sLengthMenu: '_MENU_',
        searchPlaceholder: "Search",
        info: "_START_ - _END_ of _TOTAL_ items",
        paginate: {
            next: ' <i class=" fa fa-angle-right"></i>',
            previous: '<i class="fa fa-angle-left"></i> '
        },
    },
    initComplete: (settings, json)=>{
        $('.dataTables_filter').appendTo('#tableSearch');
        $('.dataTables_filter').appendTo('.search-input');
    },
    "iDisplayLength": 50,
});
</script>