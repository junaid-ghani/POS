<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="submenu-open">
                    <ul>
                        {{-- <li><a href="{{ route('location.dashboard') }}" @if(isset($set) && $set == 'dashboard') class="active" @endif><i data-feather="box"></i><span>Dashboard</span></a></li> --}}
                        
                        <li><a href="{{ route('location.create_sale',Auth::guard('location')->id()) }}" @if(isset($set) && $set == 'create_sale') class="active" @endif><i data-feather="box"></i><span>Home</span></a></li>
                        <li class="submenu">
                            <a href="javascript:void(0);" class="subdrop @if(isset($set) && ($set == 'assign_products' || $set == 'transfer_products' || $set == 'stocks')) active @endif"><i data-feather="package"></i><span>Inventory</span><span class="menu-arrow"></span></a>
                            <ul>
                                
                                <li><a href="{{ route('location.stocks') }}" @if(isset($set) && $set == 'stocks') class="active" @endif>Manage Inventory</a></li>
                                <li><a href="{{ route('location.transfer_products') }}" @if(isset($set) && $set == 'transfer_products') class="active" @endif>Transfers</a></li>
                                {{-- <li><a href="{{ route('admin.assign_products') }}" @if(isset($set) && $set == 'assign_products') class="active" @endif>Assign Products</a></li> --}}
                            </ul>
                        </li>
                        <li><a href="{{ route('location.customers') }}" @if(isset($set) && $set == 'customers') class="active" @endif><i data-feather="user"></i><span>Customers</span></a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>