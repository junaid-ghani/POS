<?php

namespace App\Http\Controllers\Location;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use Validator;
use DataTables;
use App\Models\Customer;

class LocationCustomerController extends Controller
{
    public function index()
    {
        $data['set'] = 'customers';
        return view('location.customer.customers',$data);
    }

    public function get_customers(Request $request)
    {

        $location_id =  Auth::guard('location')->id();
        
        if ($location_id) {
            
            $data = Customer::orderby('customer_id','desc')->where('location_added_by',$location_id)->where('customer_added_by',null)->get();
        }        

        return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function($row){
                   
                    $btn = '<div class="hstack gap-2 fs-15">';

                    $btn .= '<a href="'.route('location.edit_customer',['id'=>$row->customer_id]).'" class="btn btn-icon btn-sm btn-info" title="Edit"><i class="fa fa-edit"></i></a> ';
                    $btn .= '<a href="'.route('location.delete_customer',['id'=>$row->customer_id]).'" class="btn btn-icon btn-sm btn-danger" title="Delete"><i class="fa fa-remove"></i></a> ';                  
                    
                    $btn .= '</div>';

                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
    }

    public function add_customer(Request $request)
    {
        if($request->has('submit'))
        {
            $rules = ['customer_name' => 'required',
                      'customer_email' => 'required|email',
                    //   'customer_phone' => 'required',
                    //   'customer_gender' => 'required',
                    //   'customer_dob' => 'required',
                    //   'customer_address' => 'required'
                    ];

            $messages = ['customer_name.required' => 'Please Enter Customer',
                         'customer_email.required' => 'Please Enter Email',
                         'customer_email.email' => 'Please Enter Valid Email',
                        //  'customer_phone.required' => 'Please Phone',
                        //  'customer_gender.required' => 'Please Select Gender',
                        //  'customer_dob.required' => 'Please Select Date of Birth',
                        //  'customer_address.required' => 'Please Enter Address'
                        ];

            $validator=Validator::make($request->all(),$rules,$messages);

            if($validator->fails())
            {
                return redirect()->back()->withErrors($validator->errors())->withInput();
            }
            else
            {
                $where_check['customer_email'] = $request->customer_email;
                $check_customer = Customer::where($where_check)->count();

                if($check_customer > 0)
                {
                    return redirect()->back()->with('error','Customer Already Exists')->withInput();
                }
                else
                {
                    $location_id =  Auth::guard('location')->id();
                    
                    $ins['customer_name']       = $request->customer_name;
                    $ins['customer_email']      = $request->customer_email;
                    $ins['customer_phone']      = $request->customer_phone;
                    // $ins['customer_gender']     = $request->customer_gender;
                    // $ins['customer_dob']        = $request->customer_dob;
                    // $ins['customer_address']    = $request->customer_address;
                    
                    $ins['customer_added_on']   = date('Y-m-d H:i:s');
                    $ins['customer_updated_on'] = date('Y-m-d H:i:s');

                    $ins['customer_added_by']   = null;
                    $ins['customer_updated_by'] = null;

                    $ins['location_added_by']   = $location_id;
                    $ins['location_updated_by'] = $location_id;
                    
                    $ins['customer_status']     = 1;
                    $add = Customer::create($ins);

                    if($add)
                    {
                        // return redirect()->back()->with('success','Customer Added Successfully');
                        return redirect()->route('location.customers')->with('success','Customer Added Successfully');
                    }
                }
            }
        }

        $data['set'] = 'customers';
        return view('location.customer.add_customer',$data);
    }

    public function edit_customer(Request $request)
    {
        if($request->has('submit'))
        {
            $rules = ['customer_name' => 'required',
                      'customer_email' => 'required|email',
                    //   'customer_phone' => 'required',
                    //   'customer_gender' => 'required',
                    //   'customer_dob' => 'required',
                    //   'customer_address' => 'required'
                    ];

            $messages = ['customer_name.required' => 'Please Enter Customer',
                         'customer_email.required' => 'Please Enter Email',
                         'customer_email.email' => 'Please Enter Valid Email',
                        //  'customer_phone.required' => 'Please Enter Phone',
                        //  'customer_gender.required' => 'Please Select Gender',
                        //  'customer_dob.required' => 'Please Select Date of Birth',
                        //  'customer_address.required' => 'Please Enter Address'
                        ];

            $validator=Validator::make($request->all(),$rules,$messages);

            if($validator->fails())
            {
                return redirect()->back()->withErrors($validator->errors())->withInput();
            }
            else
            {
                $where_check['customer_email'] = $request->customer_email;
                $check_customer = Customer::where($where_check)->where('customer_id','!=',$request->segment(3))->count();

                if($check_customer > 0)
                {
                    return redirect()->back()->with('error','Customer Already Exists')->withInput();
                }
                else
                {
                    $location_id =  Auth::guard('location')->id();
                    $upd['customer_name']       = $request->customer_name;
                    $upd['customer_email']      = $request->customer_email;
                    $upd['customer_phone']      = $request->customer_phone;
                    // $upd['customer_gender']     = $request->customer_gender;
                    // $upd['customer_dob']        = $request->customer_dob;
                    // $upd['customer_address']    = $request->customer_address;
                    $ins['customer_added_by']   = null;
                    $ins['customer_updated_by'] = null;

                    $ins['location_added_by']   = $location_id;
                    $ins['location_updated_by'] = $location_id;
                    
                    $add = Customer::where('customer_id',$request->segment(3))->update($upd);

                    // return redirect()->back()->with('success','Customer Updated Successfully');
                    return redirect()->route('location.customers')->with('success','Customer Updated Successfully');
                }
            }
        }

        $where['customer_id'] = $request->segment(3);
        $data['customer'] = Customer::where($where)->first();
        
        if(!isset($data['customer']))
        {
            return redirect()->route('location.customers');
        }

        $data['set'] = 'customers';
        return view('location.customer.edit_customer',$data);
    }
    public function delete_customer($id)
    {
        $delete_customer  = Customer::find($id);
        $delete_customer->delete();
        return redirect()->route('location.customers')->with('success','Delete User Successfully!');
    }

    public function customer_status(Request $request)
    {
        $status = $request->segment(4);

        if($status == 1)
        {
            $upd['customer_status'] = 0;
        }
        else
        {
            $upd['customer_status'] = 1;
        }

        $where['customer_id'] = $request->segment(3);
        Customer::where($where)->update($upd);
        
        return redirect()->back()->with('success','Status Changed Successfully!');
    }
}
