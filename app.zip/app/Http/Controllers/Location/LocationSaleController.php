<?php

namespace App\Http\Controllers\Location;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Mail;
use Cart;
use Auth;
use Validator;
use DataTables;
use App\Models\Location;
use App\Models\Customer;
use App\Models\User;
use App\Models\Category;
use App\Models\Product;
use App\Models\Stock;
use App\Models\Sale;
use App\Models\SaleItem;

class LocationSaleController extends Controller
{
    // public function index()
    // {
    //     $data['locations'] = Location::where('location_status',1)->get();
    //     $data['today'] = date('Y-m-d');
    //     $data['set'] = 'sales';
    //     return view('admin.sale.sales',$data);
    // }

    // public function get_sales(Request $request)
    // {
        
    //     $where = 'sale_status = 1';

    //     if(!empty($request->location_id))
    //     {
    //         $where .= ' AND sale_location = "'.$request->location_id.'"';
    //     }

    //     if(!empty($request->start_date))
    //     {
    //         $where .= ' AND sale_added_on >= "'.date('Y-m-d 00:00:00',strtotime($request->start_date)).'"';
    //     }

    //     if(!empty($request->end_date))
    //     {
    //         $where .= ' AND sale_added_on <= "'.date('Y-m-d 23:59:59',strtotime($request->end_date)).'"';
    //     }

    //     $data = Sale::getDetails($where);

    //     return Datatables::of($data)
    //             ->addIndexColumn()
    //             ->addColumn('sale_date', function($row){

    //                 $sale_date = date('d M Y h:i A',strtotime($row->sale_added_on));
    //                 return $sale_date;

    //             })
    //             ->addColumn('sellers', function($row){

    //                 $sellers = json_decode($row->sale_sellers,true);

    //                 $users = User::whereIn('user_id',$sellers)->get();

    //                 $sellers = array_column($users->toArray(),'user_name');
    //                 $sellers = implode(", ",$sellers);

    //                 return $sellers;

    //             })
    //             ->addColumn('action', function($row){

    //                 $btn = '<div class="hstack gap-2 fs-15">';

    //                 $btn .= '<a href="javascript:void(0)" class="btn btn-icon btn-sm btn-dark" title="View"><i class="fa fa-file"></i></a>';
                    
    //                 $btn .= '</div>';

    //                 return $btn;
    //             })
    //             ->rawColumns(['action'])
    //             ->make(true);
    // }

    // public function search_location(Request $request)
    // {
    //     if($request->has('submit'))
    //     {
    //         $rules = ['location' => 'required'];
            
    //         $messages = ['location.required' => 'Please Select Location'];
                        
    //         $validator = Validator::make($request->all(),$rules,$messages);
            
    //         if($validator->fails())
    //         {
    //             return redirect()->back()->withErrors($validator->errors())->withInput();
    //         }
    //         else
    //         {
    //             Cart::clear();

    //             return redirect()->route('admin.create_sale',['id'=>$request->location]);
    //         }
    //     }

    //     $data['locations'] = Location::where('location_status',1)->get();

    //     $data['set'] = 'create_sale';
    //     return view('admin.sale.search_location',$data);
    // }

    public function create_sale(Request $request)
    {
                
        $data['location'] = Location::where('location_id',$request->segment(3))->first();        

        if(!isset($data['location']))
        {
            return redirect()->route('search_location');
        }

        $data['customers'] = Customer::where('customer_status',1)->get();

        $where_seller['user_role'] = 4;
        $where_seller['user_status'] = 1;
        $data['sellers'] = User::where($where_seller)->orderby('user_name','asc')->get();

        $data['category_list'] = Category::where('category_status',1)->get();
        
        $where_product['stock_location'] = $request->segment(3);
        $where_product['product_status'] = 1;
        
        $products = $data['products'] = Stock::getProducts($where_product);
        // dd($data['products']);
        
        if($products->count() > 0)
        {
            foreach($products as $product)
            {
                $category_products[$product->product_category][] = array('id' => $product->product_id,'name' => $product->product_name,'category' => $product->category_name,'price' => $product->product_retail_price,'image' => $product->product_image,'stock_qty' => $product->stock_quantity);
            }

            $data['category_products'] = $category_products;           
        }
        
        $data['cart_items'] = Cart::getContent();
                
        $data['set'] = 'create_sale';
        return view('location.sale.create_sale',$data);
    }

    public function add_sale(Request $request)
    {

        // dd($request->all());

        if($request->has('submit'))
        {

            // dd($request->all());

            $rules = ['sale_customer' => 'required'];
            
            $messages = ['sale_customer.required' => 'Please Select Customer'];
                        
            // dd($request->all());
            $validator = Validator::make($request->all(),$rules,$messages);
            
            if($validator->fails())
            {
                return redirect()->back()->withErrors($validator->errors())->withInput();
            }
            else
            {
                if(!$request->has('products'))
                {
                    return redirect()->back()->with('error','Please Select Products');
                }

                $total_sale = Sale::count() + 1;

                $invoice_no = sprintf('%06d', $total_sale);

                $ins['sale_location']           = $request->sale_location;
                $ins['sale_invoice_no']         = $invoice_no;
                $ins['sale_customer']           = $request->sale_customer;
                $ins['sale_sellers']            = json_encode($request->sale_sellers);
                $ins['sale_sub_total']          = $request->sale_sub_total;
                $ins['sale_discount_type']      = $request->sale_discount_type;
                $ins['sale_discount']           = $request->sale_discount;
                $ins['sale_discount_amount']    = $request->sale_discount_amount;
                $ins['sale_tax']                = $request->sale_tax;
                $ins['sale_tax_amount']         = $request->sale_tax_amount;
                $ins['sale_grand_total']        = $request->sale_grand_total;
                $ins['sale_pay_cash']           = $request->method_cash;
                $ins['sale_pay_ccard']          = $request->method_credit;
                $ins['sale_pay_dcard']          = $request->method_debit;

                $ins['sale_pay_payment_app']           = $request->method_payment_app;
                $ins['sale_pay_check']          = $request->method_check;
                $ins['sale_pay_split_payment']          = $request->method_split_payment;

                $ins['sale_added_on']           = date('Y-m-d H:i:s');
                $ins['sale_added_by']           = Auth::guard('location')->id();
                $ins['sale_updated_on']         = date('Y-m-d H:i:s');
                $ins['sale_updated_by']         = Auth::guard('location')->id();
                $ins['sale_status']             = 1;

                if($request->method_cash == 1)
                {
                    $ins['sale_pay_camount'] = $request->pcash;
                }
                else
                {
                    $ins['sale_pay_camount'] = NULL;
                }

                if($request->method_credit == 1)
                {
                    $ins['sale_pay_cc_transaction'] = $request->pcredit;
                }
                else
                {
                    $ins['sale_pay_cc_transaction'] = NULL;
                }

                if($request->method_debit == 1)
                {
                    $ins['sale_pay_dc_transaction'] = $request->pdebit;
                    $ins['sale_pay_dc_last_no'] = $request->last4;
                    
                }
                else
                {
                    $ins['sale_pay_dc_transaction'] = NULL;
                }
                
                if($request->method_payment_app == 1)
                {
                    $ins['sale_pay_pa_transaction'] = $request->payment_app;
                    
                }
                else
                {
                    $ins['sale_pay_pa_transaction'] = NULL;
                }

                if($request->method_check == 1)
                {
                    $ins['sale_pay_check_transaction'] = $request->ck_name;
                    $ins['sale_pay_check_no'] = $request->ck_no;
                }
                else
                {
                    $ins['sale_pay_check_transaction'] = NULL;
                }

                if($request->method_split_payment == 1)
                {
                    $ins['sale_pay_sp_transaction'] = null;
                }
                else
                {
                    $ins['sale_pay_sp_transaction'] = NULL;
                }


                $add_sale = Sale::create($ins);

                
                if($add_sale)
                {
                    $products = $request->products;

                    foreach($products as $product)
                    {
                        $ins_item['sale_item_sale']       = $add_sale->sale_id;
                        $ins_item['sale_item_product']    = $product;
                        $ins_item['sale_item_price']      = $request->product_price[$product];
                        $ins_item['sale_item_quantity']   = $request->product_qty[$product];
                        $ins_item['sale_item_total']      = $request->product_price[$product] * $request->product_qty[$product];
                        $ins_item['sale_item_added_on']   = date('Y-m-d H:i:s');
                        $ins_item['sale_item_added_by']   = Auth::guard('location')->id();
                        $ins_item['sale_item_updated_on'] = date('Y-m-d H:i:s');
                        $ins_item['sale_item_updated_by'] = Auth::guard('location')->id();
                        $ins_item['sale_item_status']     = 1;

                        SaleItem::create($ins_item);

                        $where_stock['stock_location'] = $request->sale_location;
                        $where_stock['stock_product']  = $product;
                        $stock = Stock::where($where_stock)->first();

                        $upd['stock_quantity'] = $stock->stock_quantity - $request->product_qty[$product];
                        
                        Stock::where($where_stock)->update($upd);
                    }

                    Cart::clear();

                    return redirect()->route('location.create_sale')->with('success','Sale Created Successfully');
                }
            }            
        }
    }

    public function add_to_cart(Request $request)
    {        
        $where['product_id'] = $request->product_id;
        $product = Product::getDetail($where);

        $uniqueId = uniqid();

        Cart::add([
            'id' => $uniqueId,
            'name' => $product->product_name,
            'price' => $product->product_retail_price,
            'quantity' => $request->qty,
            'attributes' => array(
                'product_id' => $request->product_id, // Keep the original product ID as an attribute
                'min_price' => $product->product_min_price,
                'is_readonly' => 0,
                'code' => $product->product_code,
                'category' => $product->category_name,
                'image' => $product->product_image,
            )
        ]);

        $data['cart_items'] = Cart::getContent();

        return view('location.sale.cart_products', $data);
    }


    // public function add_to_cart(Request $request)
    // {
    //     $where['product_id'] = $request->product_id;
    //     $product = Product::getDetail($where);

    //     Cart::add([
    //         'id' => $request->product_id,
    //         'name' => $product->product_name,
    //         'price' => $product->product_retail_price,
    //         'quantity' => $request->qty,
    //         'attributes' => array(
    //             'min_price' => $product->product_min_price,
    //             'is_readonly' => 0,
    //             'code' => $product->product_code,
    //             'category' => $product->category_name,
    //             'image' => $product->product_image,
    //         )
    //     ]);
        
    //     $data['cart_items'] = Cart::getContent();
        
    //     return view('location.sale.cart_products',$data);
    // }


    public function update_cart(Request $request)
    {
        if (isset($request->edit_price) && $request->edit_price >= 0) {
            
            Cart::update(
                $request->product_id,
                [
                    'quantity' => [
                        'relative' => false,
                        'value' => $request->qty
                    ],
                    'price' => $request->edit_price
                    ]
            );
            
        }else{

            Cart::update(
                $request->product_id,
                [
                    'quantity' => [
                        'relative' => false,
                        'value' => $request->qty
                    ]                                    
                ]
            );

        }
    }

    public function used_update_cart(Request $request)
    {   

        if (isset($request->edit_price) && $request->edit_price >= 0) {
            
            Cart::update(
                $request->product_id,
                [
                    'quantity' => [
                        'relative' => false,
                        'value' => $request->qty
                    ],
                    'price' => $request->edit_price,
                    'is_readonly' => $request->is_readonly
                ]
            );           
        }else{

            Cart::update(
                $request->product_id,
                [
                    'quantity' => [
                        'relative' => false,
                        'value' => $request->qty
                    ],              
                    'is_readonly' => $request->is_readonly                    
                ]
            );
        }

        $data['cart_items'] = Cart::getContent();
        return view('location.sale.cart_products',$data);
    }

    public function new_update_cart(Request $request)
    {   

        if (isset($request->edit_price) && $request->edit_price >= 0) {
            
            Cart::update(
                $request->product_id,
                [
                    'quantity' => [
                        'relative' => false,
                        'value' => $request->qty
                    ],
                    'price' => $request->edit_price,
                    'is_readonly' => $request->is_readonly                    
                ]
            );           
        }else{

            Cart::update(
                $request->product_id,
                [
                    'quantity' => [
                        'relative' => false,
                        'value' => $request->qty
                    ],
                    'is_readonly' => $request->is_readonly                                    
                ]
            );

        }

        $data['cart_items'] = Cart::getContent();
        return view('location.sale.cart_products',$data);
    }

    public function remove_cart(Request $request)
    {
        Cart::remove($request->product_id);

        $data['cart_items'] = Cart::getContent();

        return view('location.sale.cart_products',$data);
    }

    public function clear_cart(Request $request)
    {
        Cart::clear();

        return redirect()->back();
    }

    public function reset_sale(Request $request)
    {
        Cart::clear();

        return redirect()->back();
    }
}