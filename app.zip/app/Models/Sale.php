<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Sale extends Model
{
    protected $table = 'sales';

    protected $primaryKey = 'sale_id';

    public $timestamps = false;

    protected $fillable = ['sale_location','sale_invoice_no','sale_customer','sale_sellers','sale_sub_total','sale_discount_type','sale_discount','sale_discount_amount','sale_tax','sale_tax_amount','sale_grand_total','sale_pay_cash','sale_pay_ccard','sale_pay_dcard','sale_pay_camount','sale_pay_cc_transaction','sale_pay_dc_transaction','sale_added_on','sale_added_by','sale_updated_on','sale_updated_by','sale_status'];

    public static function getDetails($where)
    {
        $sale = new Sale;

        return $sale->select('*')
                        ->join('customers', 'customers.customer_id','=', 'sales.sale_customer')
                        ->join('locations', 'locations.location_id','=', 'sales.sale_location')
                        ->join('users', 'users.user_id','=', 'sales.sale_added_by')
                        ->whereRaw($where)
                        ->orderby('sale_id','desc')
                        ->get();
    }
}