<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Location\{
    LocationLoginController,
    LocationDashboardController,
    LocationProfileController,
    LocationLogoutController,
    LocationCustomerController,
    LocationSaleController,
    LocationStockController,
    LocationTransferProductController
};

// 
use App\Http\Controllers\Admin\{
    AdminLoginController,
    AdminDashboardController,
    AdminSaleController,
    AdminAssignProductController,
    AdminTransferProductController,
    AdminStockController,
    AdminProductController,
    AdminCategoryController,
    AdminCustomerController,
    AdminLocationController,
    AdminUserController,
    AdminProfileController,
    AdminLogoutController
};


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::middleware(['checklocationlogin'])->group(function () {

    Route::match(['get','post'],'/', [LocationLoginController::class, 'index'])->name('login');
    Route::post('/get_index', [LocationLoginController::class, 'get_index'])->name('get_index');

});

Route::middleware(['checklocation'])->group(function () {

    Route::prefix('location')->group(function () {

        Route::name('location.')->group(function () {
            
            //Dashboard

            Route::get('dashboard', [LocationDashboardController::class, 'index'])->name('dashboard');
            
            //Profile

            Route::match(['get','post'],'profile', [LocationProfileController::class, 'index'])->name('profile');

            //Logout

            Route::get('logout', [LocationLogoutController::class, 'index'])->name('logout');
            
            //Customer

            Route::get('customers', [LocationCustomerController::class, 'index'])->name('customers');
            Route::post('get_customers', [LocationCustomerController::class, 'get_customers'])->name('get_customers');
            Route::match(['get','post'],'add_customer', [LocationCustomerController::class, 'add_customer'])->name('add_customer');
            Route::match(['get','post'],'edit_customer/{id}', [LocationCustomerController::class, 'edit_customer'])->name('edit_customer');
            Route::match(['get','post'],'delete_customer/{id}', [LocationCustomerController::class, 'delete_customer'])->name('delete_customer');
            Route::get('customer_status/{id}/{status}', [LocationCustomerController::class, 'customer_status'])->name('customer_status');

            //Sale
            
            Route::get('create_sale/{id}', [LocationSaleController::class, 'create_sale'])->name('create_sale');
            Route::post('add_sale', [LocationSaleController::class, 'add_sale'])->name('add_sale');            
            Route::post('add_to_cart', [LocationSaleController::class, 'add_to_cart'])->name('add_to_cart');
            Route::post('update_cart', [LocationSaleController::class, 'update_cart'])->name('update_cart');
            Route::post('used_update_cart', [LocationSaleController::class, 'used_update_cart'])->name('used_update_cart');
            Route::post('new_update_cart', [LocationSaleController::class, 'new_update_cart'])->name('new_update_cart');
            Route::post('remove_cart', [LocationSaleController::class, 'remove_cart'])->name('remove_cart');
            Route::get('clear_cart', [LocationSaleController::class, 'clear_cart'])->name('clear_cart');
            Route::get('reset_sale/{id}', [LocationSaleController::class, 'reset_sale'])->name('reset_sale');

            //Transfer Product

            Route::match(['get','post'],'transfer_products', [LocationTransferProductController::class, 'index'])->name('transfer_products');
            Route::post('select_transfer_products', [LocationTransferProductController::class, 'select_transfer_products'])->name('select_transfer_products');
            Route::post('select_to_location', [LocationTransferProductController::class, 'select_to_location'])->name('select_to_location');

            //Stock

            Route::get('stocks', [LocationStockController::class, 'index'])->name('stocks');
            Route::post('get_stocks', [LocationStockController::class, 'get_stocks'])->name('get_stocks');
            Route::post('update_stock', [LocationStockController::class, 'update_stock'])->name('update_stock');
            Route::get('delete_stock/{id}', [LocationStockController::class, 'delete_stock'])->name('delete_stock');
        });

    });

});

Route::middleware(['checkuserlogin'])->group(function () {

    Route::match(['get','post'],'admin', [AdminLoginController::class, 'index'])->name('admin');
    Route::match(['get','post'],'admin_forgot_password', [AdminLoginController::class, 'forgot_password'])->name('admin_forgot_password');

});

Route::middleware(['checkuser'])->group(function () {

    Route::prefix('admin')->group(function () {

        Route::name('admin.')->group(function () {
            
            //Dashboard

            Route::get('dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');

            //Sale

            Route::get('sales', [AdminSaleController::class, 'index'])->name('sales');
            Route::post('get_sales', [AdminSaleController::class, 'get_sales'])->name('get_sales');
            Route::match(['get','post'],'search_location', [AdminSaleController::class, 'search_location'])->name('search_location');            
            Route::get('create_sale/{id}', [AdminSaleController::class, 'create_sale'])->name('create_sale');
            Route::post('add_sale', [AdminSaleController::class, 'add_sale'])->name('add_sale');            
            Route::post('add_to_cart', [AdminSaleController::class, 'add_to_cart'])->name('add_to_cart');
            Route::post('update_cart', [AdminSaleController::class, 'update_cart'])->name('update_cart');
            Route::post('remove_cart', [AdminSaleController::class, 'remove_cart'])->name('remove_cart');
            Route::get('clear_cart', [AdminSaleController::class, 'clear_cart'])->name('clear_cart');
            Route::get('reset_sale/{id}', [AdminSaleController::class, 'reset_sale'])->name('reset_sale');

            //Assign Product

            Route::match(['get','post'],'assign_products', [AdminAssignProductController::class, 'index'])->name('assign_products');            
            Route::post('select_assign_products', [AdminAssignProductController::class, 'select_assign_products'])->name('select_assign_products');
            Route::post('select_products', [AdminAssignProductController::class, 'select_products'])->name('select_products');
            //Transfer Product

            Route::match(['get','post'],'transfer_products', [AdminTransferProductController::class, 'index'])->name('transfer_products');
            Route::post('select_transfer_products', [AdminTransferProductController::class, 'select_transfer_products'])->name('select_transfer_products');
            Route::post('select_to_location', [AdminTransferProductController::class, 'select_to_location'])->name('select_to_location');

            //Stock

            Route::get('stocks', [AdminStockController::class, 'index'])->name('stocks');
            Route::post('get_stocks', [AdminStockController::class, 'get_stocks'])->name('get_stocks');
            Route::post('update_stock', [AdminStockController::class, 'update_stock'])->name('update_stock');
            Route::get('delete_stock/{id}', [AdminStockController::class, 'delete_stock'])->name('delete_stock');

            //Product

            Route::get('products', [AdminProductController::class, 'index'])->name('products');
            Route::post('get_products', [AdminProductController::class, 'get_products'])->name('get_products');
            Route::match(['get','post'],'add_product', [AdminProductController::class, 'add_product'])->name('add_product');
            Route::match(['get','post'],'edit_product/{id}', [AdminProductController::class, 'edit_product'])->name('edit_product');
            Route::match(['get','post'],'delete_product/{id}', [AdminProductController::class, 'delete_product'])->name('delete_product');
            Route::get('view_product/{id}', [AdminProductController::class, 'view_product'])->name('view_product');
            Route::get('product_status/{id}/{status}', [AdminProductController::class, 'product_status'])->name('product_status');

            //Route::match(['get','post'],'products_location', [AdminProductController::class, 'products_location'])->name('products_location');
            //Route::post('select_transfer_products', [AdminTransferProductController::class, 'select_transfer_products'])->name('select_transfer_products');
           // Route::post('select_to_location', [AdminTransferProductController::class, 'select_to_location'])->name('select_to_location');

            //Category

            Route::get('category', [AdminCategoryController::class, 'index'])->name('category');
            Route::post('get_category', [AdminCategoryController::class, 'get_category'])->name('get_category');
            Route::post('add_category', [AdminCategoryController::class, 'add_category'])->name('add_category');
            Route::post('edit_category', [AdminCategoryController::class, 'edit_category'])->name('edit_category');
            Route::match(['get','post'],'delete_category/{id}', [AdminCategoryController::class, 'delete_category'])->name('delete_category');
            Route::post('get_category_details', [AdminCategoryController::class, 'get_category_details'])->name('get_category_details');
            Route::get('category_status/{id}/{status}', [AdminCategoryController::class, 'category_status'])->name('category_status');

            //Customer

            Route::get('customers', [AdminCustomerController::class, 'index'])->name('customers');
            Route::post('get_customers', [AdminCustomerController::class, 'get_customers'])->name('get_customers');
            Route::match(['get','post'],'add_customer', [AdminCustomerController::class, 'add_customer'])->name('add_customer');
            Route::match(['get','post'],'edit_customer/{id}', [AdminCustomerController::class, 'edit_customer'])->name('edit_customer');
            Route::match(['get','post'],'delete_customer/{id}', [AdminCustomerController::class, 'delete_customer'])->name('delete_customer');
            Route::get('customer_status/{id}/{status}', [AdminCustomerController::class, 'customer_status'])->name('customer_status');

            //Location

            Route::get('locations', [AdminLocationController::class, 'index'])->name('locations');
            Route::post('get_locations', [AdminLocationController::class, 'get_locations'])->name('get_locations');
            Route::match(['get','post'],'add_location', [AdminLocationController::class, 'add_location'])->name('add_location');
            Route::match(['get','post'],'edit_location/{id}', [AdminLocationController::class, 'edit_location'])->name('edit_location');
            Route::get('location_status/{id}/{status}', [AdminLocationController::class, 'location_status'])->name('location_status');

            //User

            Route::get('users', [AdminUserController::class, 'index'])->name('users');
            Route::post('get_users', [AdminUserController::class, 'get_users'])->name('get_users');
            Route::match(['get','post'],'add_user', [AdminUserController::class, 'add_user'])->name('add_user');
            Route::match(['get','post'],'edit_user/{id}', [AdminUserController::class, 'edit_user'])->name('edit_user');
            Route::get('user_status/{id}/{status}', [AdminUserController::class, 'user_status'])->name('user_status');

            //Profile

            Route::match(['get','post'],'profile', [AdminProfileController::class, 'index'])->name('profile');

            //Logout

            Route::get('logout', [AdminLogoutController::class, 'index'])->name('logout');

        });

    });

});