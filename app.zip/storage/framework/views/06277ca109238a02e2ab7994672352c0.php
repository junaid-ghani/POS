<?php $__env->startSection('title', config('constants.site_title') . ' | Add User'); ?>
<?php $__env->startSection('contents'); ?>
    <div class="content">
        <div class="page-header">
            <div class="add-item d-flex">
                <div class="page-title">
                    <h4>Users</h4>
                    <h6>Add User</h6>
                </div>
            </div>
            <ul class="table-top-head">
                <li>
                    <div class="page-btn">
                        <a href="<?php echo e(route('admin.users')); ?>" class="btn btn-secondary"><i data-feather="arrow-left"
                                class="me-2"></i>Back</a>
                    </div>
                </li>
                <li>
                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i
                            data-feather="chevron-up" class="feather-chevron-up"></i></a>
                </li>
            </ul>
        </div>
        <form id="user_form" action="<?php echo e(route('admin.add_user')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-body">
                    <div class="new-employee-field">
                        <div class="card-title-head">
                            <h6><span><i data-feather="info" class="feather-edit"></i></span>User Information</h6>
                        </div>
                        <div class="row mb-3">
                            <div class="col-lg-6 col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Name</label>
                                    <input type="text" name="user_name" class="form-control"
                                        value="<?php echo e(old('user_name')); ?>" autocomplete="off">
                                    <?php if($errors->has('user_name')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('user_name')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Role</label>
                                    <select name="user_role" class="form-control selectbox">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($role->role_id); ?>"><?php echo e($role->role_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <div id="user_role_error"></div>
                                    <?php if($errors->has('user_role')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('user_role')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="text" name="user_email" class="form-control"
                                        value="<?php echo e(old('user_email')); ?>" autocomplete="off">
                                    <?php if($errors->has('user_email')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('user_email')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="input-blocks mb-md-0 mb-sm-3">
                                    <label>Password</label>
                                    <div class="pass-group">
                                        <input type="password" name="user_password" class="pass-input"
                                            value="<?php echo e(old('user_password')); ?>" autocomplete="off">
                                        <span class="fas toggle-password fa-eye-slash"></span>
                                    </div>
                                    <?php if($errors->has('user_password')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('user_password')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="col-lg-6 col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Salary Type</label>
                                    <select name="user_salary_type" id="user_salary_type" class="form-control selectbox"
                                        onchange="select_type()">
                                        <option value="">Select</option>
                                        <option value="1">None</option>
                                        <option value="2">Fixed Commission</option>
                                        <option value="3">Commission Steps</option>
                                    </select>
                                    <div id="user_salary_type_error"></div>
                                    <?php if($errors->has('user_salary_type')): ?>
                                        <small class="text-danger"><?php echo e($errors->first('user_salary_type')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row mb-3" id="step_commission_div" style="display: none">
                                <div class="table-responsive">
                                    <table class="table table-bordered mb-0">
                                        <thead>
                                            <tr>
                                                <th>From</th>
                                                <th>To</th>
                                                <th>Commission (%)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <div class="mb-3">
                                                        <input type="number" name="commissions[FROM][1]"
                                                            class="form-control" readonly value="0.00" placeholder="0.00"
                                                            autocomplete="off">                                                        
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="mb-3">
                                                        <input type="number" name="commissions[TO][1]" id="step1_to" class="form-control" placeholder="Enter To" autocomplete="off">
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="mb-3">
                                                        <input type="number" name="commissions[AMOUNT][1]"
                                                            class="form-control user_commission" placeholder="Enter Commission (%)"  autocomplete="off">
                                                        <small class="text-danger user_commission_error"></small>
                                                    </div>
                                                </td>
                                            </tr>


                                            <tr>
                                                <td>
                                                    <div class="mb-3">
                                                        <input type="number" name="commissions[FROM][2]" class="form-control" readonly id="step2_from" value="" placeholder="0.01"
                                                            autocomplete="off">
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="mb-3">
                                                        <input type="number" name="commissions[TO][2]" class="form-control commission_step2" id="step2_to" placeholder="Enter To" autocomplete="off">
                                                        <small class="text-danger user_commission_error_step2"></small>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="mb-3">
                                                        <input type="number" name="commissions[AMOUNT][2]"
                                                            class="form-control user_commission" placeholder="Enter Commission (%)"
                                                            autocomplete="off">
                                                            <small class="text-danger user_commission_error"></small>
                                                    </div>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    <div class="mb-3">
                                                        <input type="number" name="commissions[FROM][3]"
                                                            class="form-control" readonly value="" id="step3_from" placeholder="0.01"
                                                            autocomplete="off">
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="mb-3">
                                                        <input type="number" name="commissions[TO][3]" class="form-control commission_step2" readonly value="99999.99" placeholder="99999.99"  autocomplete="off">
                                                        <small class="text-danger user_commission_error_step2"></small>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="mb-3">
                                                        <input type="number" name="commissions[AMOUNT][3]"
                                                            class="form-control user_commission" placeholder="Enter Commission (%)"
                                                            autocomplete="off">
                                                        <small class="text-danger user_commission_error"></small>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            
                            <div class="col-lg-6 col-md-6" id="fixed_commission_div" style="display: none">
                                <div class="mb-3">
                                    <label class="form-label">Fixed Commission (%)</label>
                                    <input type="number" name="user_commission" class="form-control user_commission"  value="<?php echo e(old('user_commission')); ?>" autocomplete="off">
                                    <small class="text-danger user_commission_error"></small>
                                    <?php if($errors->has('user_commission')): ?>
                                        <small class="text-danger user_commission_error"><?php echo e($errors->first('user_commission')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-end mb-3">
                <button type="submit" name="submit" class="btn btn-submit" value="submit">Save</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_script'); ?>
    <script>
        
        $(document).ready(function() {

            $("#step1_to").on('input', function () {
                let step1_to_raw = $("#step1_to").val();
                let step1_to = parseFloat(step1_to_raw);
                
                if (!isNaN(step1_to)) {
                    $("#step1_to").blur(function () {
                        $("#step1_to").val(step1_to.toFixed(2));
                        let step2_from = parseFloat(step1_to) + 0.01;
                        $("#step2_from").prop("value", step2_from.toFixed(2));
                    });

                } else {
                    $("#step2_from").prop("value", "");
                }
            });

            $("#step2_to").on('input', function () {

                let step2_to_raw = $("#step2_to").val();
                let step2_to = parseFloat(step2_to_raw);
                
                if (!isNaN(step2_to)) {
                    $("#step2_to").blur(function () {
                        $("#step2_to").val(step2_to.toFixed(2));
                        let step3_from = parseFloat(step2_to) + 0.01;
                        $("#step3_from").prop("value", step3_from.toFixed(2));
                    })

                } else {
                    $("#step3_from").prop("value", "");
                }
            });
            
            
            $('.user_commission').on('input', function() {
                var value = $(this).val();
                if (value < 1 || value > 100) {
                    $(this).val('');
                    $('.user_commission_error').html('Please enter a commission value between 1 and 100.');
                }
            });
            $('.commission_step2').on('input', function() {
                var value = $(this).val();
                if (value > 99999.99) {
                    $(this).val('');
                    $('.user_commission_error_step2').html('value Should be less than 99999.99');
                }
            });
        });

        function select_type() {
            var salary_type = $("#user_salary_type").val();

            $("#fixed_commission_div").hide();
            $("#step_commission_div").hide();

            if (salary_type == 2) {
                $("#fixed_commission_div").show();
            }

            if (salary_type == 3) {
                $("#step_commission_div").show();
            }
        }

        user_image.onchange = evt => {
            const [file] = user_image.files
            if (file) {
                user_image_src.src = URL.createObjectURL(file)
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u391328125/domains/hellodev.site/public_html/POS/resources/views/admin/user/add_user.blade.php ENDPATH**/ ?>