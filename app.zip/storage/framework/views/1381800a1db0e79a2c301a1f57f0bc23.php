<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="submenu-open">
                    <ul>
                        <li><a href="<?php echo e(route('admin.dashboard')); ?>" <?php if(isset($set) && $set == 'dashboard'): ?> class="active" <?php endif; ?>><i data-feather="box"></i><span>Dashboard</span></a></li>
                        <li class="submenu">
                            <a href="javascript:void(0);" class="subdrop <?php if(isset($set) && ($set == 'sales' || $set == 'create_sale')): ?> active <?php endif; ?>"><i data-feather="shopping-cart"></i><span>Sales</span><span class="menu-arrow"></span></a>
                            <ul>
                                <li><a href="<?php echo e(route('admin.search_location')); ?>" <?php if(isset($set) && $set == 'create_sale'): ?> class="active" <?php endif; ?>>Create Sale</a></li>
                                <li><a href="<?php echo e(route('admin.sales')); ?>" <?php if(isset($set) && $set == 'sales'): ?> class="active" <?php endif; ?>>Manage Sales</a></li>
                            </ul>
                        </li>
                        <li class="submenu">
                            <a href="javascript:void(0);" class="subdrop <?php if(isset($set) && ($set == 'assign_products' || $set == 'transfer_products' || $set == 'stocks')): ?> active <?php endif; ?>"><i data-feather="package"></i><span>Inventory</span><span class="menu-arrow"></span></a>
                            <ul>
                                <li><a href="<?php echo e(route('admin.assign_products')); ?>" <?php if(isset($set) && $set == 'assign_products'): ?> class="active" <?php endif; ?>>Assign Products</a></li>
                                <li><a href="<?php echo e(route('admin.transfer_products')); ?>" <?php if(isset($set) && $set == 'transfer_products'): ?> class="active" <?php endif; ?>>Transfer Products</a></li>
                                <li><a href="<?php echo e(route('admin.stocks')); ?>" <?php if(isset($set) && $set == 'stocks'): ?> class="active" <?php endif; ?>>Stocks</a></li>
                            </ul>
                        </li>
                        <li><a href="<?php echo e(route('admin.products')); ?>" <?php if(isset($set) && $set == 'products'): ?> class="active" <?php endif; ?>><i data-feather="box"></i><span>Products</span></a></li>
                        <li><a href="<?php echo e(route('admin.category')); ?>" <?php if(isset($set) && $set == 'category'): ?> class="active" <?php endif; ?>><i data-feather="codepen"></i><span>Category</span></a></li>
                        <li><a href="<?php echo e(route('admin.customers')); ?>" <?php if(isset($set) && $set == 'customers'): ?> class="active" <?php endif; ?>><i data-feather="user"></i><span>Customers</span></a></li>
                        <li><a href="<?php echo e(route('admin.locations')); ?>" <?php if(isset($set) && $set == 'locations'): ?> class="active" <?php endif; ?>><i data-feather="home"></i><span>Locations</span></a></li>
                        <li><a href="<?php echo e(route('admin.users')); ?>" <?php if(isset($set) && $set == 'users'): ?> class="active" <?php endif; ?>><i data-feather="users"></i><span>Users</span></a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div><?php /**PATH /home5/dambozsi/public_html/resources/views/admin/partials/sidebar.blade.php ENDPATH**/ ?>