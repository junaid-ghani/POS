<?php $__env->startSection('title',config('constants.site_title').' | Create Sale'); ?>
<?php $__env->startSection('contents'); ?>
<div class="content pos-design p-0">
    <div class="btn-row d-sm-flex align-items-center">
        <div class="col-md-12 col-lg-12">
            <div class="card">
                <div class="card-header justify-content-between">
                   <div class="card-title">Search Location</div>
                </div>
                <div class="card-body">
                    <form id="search_location_form" action="<?php echo e(route('admin.search_location')); ?>" class="row gx-3 gy-2 align-items-center mt-0" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="col-sm-6">
                         <label class="visually-hidden" for="specificSizeSelect">Location</label>
                         <select name="location" class="form-select selectbox_location" id="specificSizeSelect">
                            <option value="">Location</option>
                            <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($location->location_id); ?>"><?php echo e($location->location_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </select>
                         <div id="location_error"></div>
                        </div>
                        <div class="col-auto">
                         <button type="submit" name="submit" class="btn btn-primary" value="search">Search</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_script'); ?>
<script>
$(".selectbox_location").select2({
    placeholder: "Location"
});    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home5/dambozsi/public_html/resources/views/admin/sale/search_location.blade.php ENDPATH**/ ?>