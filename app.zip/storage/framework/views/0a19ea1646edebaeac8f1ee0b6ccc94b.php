
<div class="head d-flex align-items-center justify-content-between w-100" style="margin: 20px 0 20px 0;">
    <h5>Cart</h5>
    <h6 id="min_total" class="mb-0"></h6>  
</div>
<div class="head-text d-flex align-items-center justify-content-between">
    <h6 class="d-flex align-items-center mb-0">Products Added<span class="count"><?php echo e(count($cart_items)); ?></span></h6>
    <a href="<?php echo e(route('location.clear_cart')); ?>" class="clear-noti"> Clear All </a>
</div>
<div class="product-wrap ">
    <?php if(count($cart_items)): ?>

    <?php $__currentLoopData = $cart_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <input type="hidden" name="products[<?php echo e($item->id); ?>]" value="<?php echo e($item->id); ?>">
    <input type="hidden" name="product_price[<?php echo e($item->id); ?>]" value="<?php echo e($item->price); ?>">
    <div class="product-list d-flex align-items-center justify-content-between" style="margin: 0 10px 10px 10px; border :1px solid #B8BCC9 ;">
        <div class="d-flex align-items-center product-info">
            <a href="javascript:void(0)" class="img-bg" style="cursor: auto;">
                <?php if($item->attributes->image): ?>
                <img src="<?php echo e(asset(config('constants.admin_path').'uploads/product/'.$item->attributes->image)); ?>" alt="Products">
                <?php else: ?>
                <img src="<?php echo e(asset(config('constants.admin_path').'img/no_image.jpeg')); ?>" alt="Products">
                <?php endif; ?>
            </a>
            
            <div class="info" style="margin-top: -20px;">
                                                        
                
                
                <div class="name">
                    <h6><a href="javascript:void(0)" style="cursor: default;"><?php echo e($item->name); ?></a></h6>
                </div>
                <div class="name2">
                <input type="hidden" name="product_price[<?php echo e($item->id); ?>]" value="<?php echo e($item->price); ?>">
                                                       
                <div class="input-group">
                    <span class="edit_price_symbol">$</span>
                    <input type="text" class="form-control text-center edit_price" <?php if($item->is_readonly == 1): ?> disabled <?php endif; ?> data-product_id="<?php echo e($item->id); ?>" value="<?php echo e($item->price); ?>" >                                            
                </div>
                <input type="hidden" id="cprd_minprice_<?php echo e($item->id); ?>" value="<?php echo e($item->attributes->min_price); ?>">
                <input type="hidden" class="cart_items citem_<?php echo e($item->id); ?>" id="cprd_price_<?php echo e($item->id); ?>" value="<?php echo e($item->price); ?>">
                </div>
            </div>
        </div>
    
            
        <div class="qty-item text-center">
            <a href="javascript:void(0);" class="dec d-flex justify-content-center align-items-center" <?php if($item->is_readonly == 1): ?> style="pointer-events: none; opacity: 0.5;" <?php endif; ?>><i data-feather="minus-circle" class="feather-14" onclick="update_cart('','<?php echo e($item->id); ?>')"></i></a>
            <input type="text" class="form-control text-center" id="quantity_<?php echo e($item->id); ?>" name="product_qty[<?php echo e($item->id); ?>]" value="<?php echo e($item->quantity); ?>" <?php if($item->is_readonly == 1): ?> disabled <?php endif; ?> onkeyup="update_cart('','<?php echo e($item->id); ?>')">         
            <a href="javascript:void(0);" class="inc d-flex justify-content-center align-items-center" <?php if($item->is_readonly == 1): ?> style="pointer-events: none; opacity: 0.5;" <?php endif; ?>><i data-feather="plus-circle" class="feather-14" onclick="update_cart('','<?php echo e($item->id); ?>')"></i></a>
        </div>
            
    
        <div class="d-flex align-items-center action">
            <a class="btn-icon edit-icon me-2 exchange_product" href="javascript:void(0)" data-p_id="<?php echo e($item->id); ?>" data-bs-toggle="modal" data-bs-target="#ExchangeModal">
                
                <i class="fa-solid fa-arrow-right-arrow-left"></i>
            </a>
            <a class="btn-icon delete-icon confirm-text" href="javascript:void(0)" onclick="remove_cart('<?php echo e($item->id); ?>')">
                <i data-feather="trash-2" class="feather-14"></i>
            </a>
        </div>

        <!-- Exchange modal -->

        <div class="modal fade" id="ExchangeModal" tabindex="-1" aria-labelledby="ExchangeModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="paymentModalLabel">Return Product</h5>
                    
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="d-flex ExchangeModalButton"> 
                        <input type="hidden" class="current_pro_id" value=""> 
                        <button type="button" class="btn btn-primary used_product" >Used</button>
                        <button type="button" class="btn btn-primary new_product" >New</button>
                    </div>
                </div>                      
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<script src="<?php echo e(asset(config('constants.admin_path').'js/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset(config('constants.admin_path').'js/script.js')); ?>"></script><?php /**PATH /home/u391328125/domains/hellodev.site/public_html/POS/resources/views/location/sale/cart_products.blade.php ENDPATH**/ ?>