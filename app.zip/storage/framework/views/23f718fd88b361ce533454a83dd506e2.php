<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="submenu-open">
                    <ul>
                        
                        
                        <li><a href="<?php echo e(route('location.create_sale',Auth::guard('location')->id())); ?>" <?php if(isset($set) && $set == 'create_sale'): ?> class="active" <?php endif; ?>><i data-feather="box"></i><span>Home</span></a></li>
                        <li class="submenu">
                            <a href="javascript:void(0);" class="subdrop <?php if(isset($set) && ($set == 'assign_products' || $set == 'transfer_products' || $set == 'stocks')): ?> active <?php endif; ?>"><i data-feather="package"></i><span>Inventory</span><span class="menu-arrow"></span></a>
                            <ul>
                                
                                <li><a href="<?php echo e(route('location.stocks')); ?>" <?php if(isset($set) && $set == 'stocks'): ?> class="active" <?php endif; ?>>Manage Inventory</a></li>
                                <li><a href="<?php echo e(route('location.transfer_products')); ?>" <?php if(isset($set) && $set == 'transfer_products'): ?> class="active" <?php endif; ?>>Transfers</a></li>
                                
                            </ul>
                        </li>
                        <li><a href="<?php echo e(route('location.customers')); ?>" <?php if(isset($set) && $set == 'customers'): ?> class="active" <?php endif; ?>><i data-feather="user"></i><span>Customers</span></a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div><?php /**PATH /home/u391328125/domains/hellodev.site/public_html/POS/resources/views/location/partials/sidebar.blade.php ENDPATH**/ ?>