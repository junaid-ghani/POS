<div class="table-list-card">
    <div class="table-top">
        <div class="search-set">
            <div class="search-input">
                <a href="javascript:void(0);" class="btn btn-searchset"><i data-feather="search" class="feather-search"></i></a>
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table id="product_table" class="table" style="width: 100%">
            <thead>
                <tr>
                    <th>Select</th>
                    <th>Product</th>
                    <th>Code</th>
                    <th>Stock</th>
                    <th>Quantity</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <input type="checkbox" name="transfer_products[<?php echo e($product->product_id); ?>]" value="<?php echo e($product->product_id); ?>">
                    </td>
                    <td><?php echo e($product->product_name); ?></td>
                    <td><?php echo e($product->product_code); ?></td>
                    <td><?php echo e($product->stock_quantity); ?></td>
                    <td>
                        <input type="number" class="form-control" name="transfer_quantity[<?php echo e($product->product_id); ?>]" autocomplete="off">
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<script>
$('#product_table').DataTable({
    "bFilter": true,
    "sDom": 'fBtlpi',
    "ordering": true,
    "language": {
        search: ' ',
        sLengthMenu: '_MENU_',
        searchPlaceholder: "Search",
        info: "_START_ - _END_ of _TOTAL_ items",
        paginate: {
            next: ' <i class=" fa fa-angle-right"></i>',
            previous: '<i class="fa fa-angle-left"></i> '
        },
    },
    initComplete: (settings, json)=>{
        $('.dataTables_filter').appendTo('#tableSearch');
        $('.dataTables_filter').appendTo('.search-input');
    },
    "iDisplayLength": 50,
});
</script><?php /**PATH /home/u391328125/domains/hellodev.site/public_html/POS/resources/views/location/transfer_product/select_transfer_products.blade.php ENDPATH**/ ?>