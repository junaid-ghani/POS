<?php $__env->startSection('title',config('constants.site_title').' | Profile'); ?>
<?php $__env->startSection('contents'); ?>
<div class="content">
    <div class="page-header">
        <div class="page-title">
            <h4>Profile</h4>
            <h6>Location Profile</h6>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <form id="profile_form" action="<?php echo e(route('location.profile')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="profile-set">
                    <div class="profile-head"></div>
                    <div class="profile-top">
                        <div class="profile-content">
                            <div class="profile-contentimg">
                                <?php if(!empty(Auth::guard('location')->user()->location_image)): ?>
                                <img src="<?php echo e(asset(config('constants.admin_path').'uploads/location/'.Auth::guard('location')->user()->location_image)); ?>" alt="img" id="blah">
                                <?php else: ?>
                                <img src="<?php echo e(asset(config('constants.admin_path').'img/no_image.png')); ?>" alt="img" id="blah">
                                <?php endif; ?>
                                <div class="profileupload">
                                    <input type="file" id="imgInp" name="location_image" accept="image/*">
                                    <a href="javascript:void(0)"><img src="<?php echo e(asset(config('constants.admin_path').'img/icons/edit-set.svg')); ?>"  alt="img"></a>
                                </div>
                            </div>
                            <div class="profile-contentname">
                                <h2><?php echo e(Auth::guard('location')->user()->location_name); ?></h2>
                                <h4>Location</h4>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-6 col-sm-12">
                        <div class="input-blocks">
                            <label class="form-label">Name</label>
                            <input type="text" name="location_name" class="form-control" value="<?php echo e(Auth::guard('location')->user()->location_name); ?>" autocomplete="off">
                            <?php if($errors->has('location_name')): ?>
                            <span class="text-danger"><?php echo e($errors->first('location_name')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-12">
                        <div class="input-blocks">
                            <label class="form-label">Tax (%)</label>
                            <input type="text" name="location_tax" value="<?php echo e(Auth::guard('location')->user()->location_tax); ?>" autocomplete="off">
                            <?php if($errors->has('location_tax')): ?>
                            <span class="text-danger"><?php echo e($errors->first('location_tax')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-12">
                        <div class="input-blocks">
                            <label class="form-label">Password</label>
                            <div class="pass-group">
                                <input type="password" name="location_password" class="pass-input form-control" value="<?php echo e(base64_decode(Auth::guard('location')->user()->location_vpassword)); ?>" autocomplete="off">
                                <span class="fas toggle-password fa-eye-slash"></span>
                            </div>
                            <?php if($errors->has('location_password')): ?>
                            <span class="text-danger"><?php echo e($errors->first('location_password')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12">
                        <button type="submit" name="submit" class="btn btn-submit me-2" value="submit">Submit</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('location.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u391328125/domains/hellodev.site/public_html/POS/resources/views/location/profile/profile.blade.php ENDPATH**/ ?>