<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<meta name="description" content="<?php echo e(config('constants.site_title')); ?>">
<meta name="robots" content="noindex, nofollow">
<title><?php echo e(config('constants.site_title')); ?></title>
<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset(config('constants.admin_path').'img/favicon.png')); ?>">
<link rel="stylesheet" href="<?php echo e(asset(config('constants.admin_path').'css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset(config('constants.admin_path').'plugins/fontawesome/css/fontawesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset(config('constants.admin_path').'plugins/fontawesome/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset(config('constants.admin_path').'css/style.css')); ?>">
</head>
<body class="account-page">
<div id="global-loader" >
    <div class="whirly-loader"> </div>
</div>
<div class="main-wrapper">
    <div class="account-content">
        <div class="login-wrapper bg-img">
            <div class="login-content">
                <form id="login_form" action="<?php echo e(route('admin')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="login-userset">
                        <div class="login-logo logo-normal">
                            <img src="<?php echo e(asset(config('constants.admin_path').'img/logo.png')); ?>" alt="img">
                        </div>
                        <a href="javascript:void(0)" class="login-logo logo-white">
                            <img src="<?php echo e(asset(config('constants.admin_path').'img/logo-white.png')); ?>"  alt="">
                        </a>
                        <div class="login-userheading">
                            <h3>Sign In</h3>
                            <h4>Access the <?php echo e(config('constants.site_title')); ?> panel using your email and password.</h4>
                        </div>
                        <div class="form-login mb-3">
                            <label class="form-label">Email Address</label>
                            <div class="form-addons">
                                <input type="text" name="user_email" class="form- control" value="<?php echo e(old('user_email')); ?>" autocomplete="off">
                                <img src="<?php echo e(asset(config('constants.admin_path').'img/icons/mail.svg')); ?>" alt="img">
                            </div>
                            <?php if($errors->has('user_email')): ?>
                            <small class="text-danger"><?php echo e($errors->first('user_email')); ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="form-login mb-3">
                            <label class="form-label">Password</label>
                            <div class="pass-group">
                                <input type="password" name="user_password" class="pass-input form-control" value="<?php echo e(old('user_password')); ?>" autocomplete="off">
                                <span class="fas toggle-password fa-eye-slash"></span>
                            </div>
                            <?php if($errors->has('user_password')): ?>
                            <small class="text-danger"><?php echo e($errors->first('user_password')); ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="form-login authentication-check">
                            <div class="row">
                                <div class="col-12 d-flex align-items-center justify-content-between">
                                    <div class="custom-control custom-checkbox"></div>
                                    <div class="text-end">
                                        <a class="forgot-link" href="<?php echo e(route('admin_forgot_password')); ?>">Forgot Password?</a>
                                    </div>
                                </div>                                    
                            </div>
                        </div>
                        <div class="form-login">
                            <button type="submit" name="submit" class="btn btn-login" value="submit">Sign In</button>
                        </div>
                        <div class="form-sociallink">
                            <div class="my-4 d-flex justify-content-center align-items-center copyright-text">
                                <p>Copyright &copy; <?php echo e(date('Y')); ?> <?php echo e(config('constants.site_title')); ?>. All rights reserved</p>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo e(asset(config('constants.admin_path').'js/jquery-3.7.1.min.js')); ?>"></script>
<script src="<?php echo e(asset(config('constants.admin_path').'js/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset(config('constants.admin_path').'js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset(config('constants.admin_path').'plugins/sweetalert/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset(config('constants.admin_path').'js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset(config('constants.admin_path').'js/form_validations.js')); ?>"></script>
<script src="<?php echo e(asset(config('constants.admin_path').'js/script.js')); ?>"></script>
<script>
<?php if(Session::has('success')): ?>
Swal.fire({
    title: "Good job!",
    text: "<?php echo e(Session::get('success')); ?>",
    type: "success",
    confirmButtonClass: "btn btn-primary",
    buttonsStyling: !1,
    icon: "success"
});
<?php endif; ?>
<?php if(Session::has('error')): ?>
Swal.fire({
    title: "Warning!",
    text: "<?php echo e(Session::get('error')); ?>",
    type: "warning",
    confirmButtonClass: "btn btn-primary",
    buttonsStyling: !1,
    icon: "warning"
});
<?php endif; ?>
</script>
</body>
</html><?php /**PATH /home5/dambozsi/public_html/resources/views/admin/login/login.blade.php ENDPATH**/ ?>