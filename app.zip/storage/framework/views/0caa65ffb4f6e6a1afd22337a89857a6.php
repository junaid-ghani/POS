<option value="">Select</option>
<?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo $location->location_id; ?>"><?php echo $location->location_name; ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/u391328125/domains/hellodev.site/public_html/POS/resources/views/location/transfer_product/select_to_location.blade.php ENDPATH**/ ?>