<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
<meta name="description" content="<?php echo e(config('constants.site_title')); ?>">
<meta name="robots" content="noindex, nofollow">
<title><?php echo $__env->yieldContent('title'); ?></title>
<?php echo $__env->make('admin.partials.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('custom_style'); ?>
</head>
<body>
<div id="global-loader">
    <div class="whirly-loader"> </div>
</div>
<div class="main-wrapper">
    <?php echo $__env->make('admin.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="page-wrapper">
        <?php echo $__env->yieldContent('contents'); ?>
    </div>
    <?php echo $__env->yieldContent('modal_contents'); ?>
</div>
<?php echo $__env->make('admin.partials.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('custom_script'); ?>
</body>
</html><?php /**PATH /home/u391328125/domains/hellodev.site/public_html/POS/resources/views/admin/layouts/app.blade.php ENDPATH**/ ?>