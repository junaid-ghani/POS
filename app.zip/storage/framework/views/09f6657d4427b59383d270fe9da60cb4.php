<?php $__env->startSection('title',config('constants.site_title').' | Edit Customer'); ?>
<?php $__env->startSection('contents'); ?>
<div class="content">
    <div class="page-header">
        <div class="add-item d-flex">
            <div class="page-title">
                <h4>Customers</h4>
                <h6>Edit Customer</h6>
            </div>
        </div>
        <ul class="table-top-head">
            <li>
                <div class="page-btn">
                    <a href="<?php echo e(route('location.customers')); ?>" class="btn btn-secondary"><i data-feather="arrow-left" class="me-2"></i>Back</a>
                </div>
            </li>
            <li>
                <a data-bs-toggle="tooltip" data-bs-placement="top" title="Collapse" id="collapse-header"><i data-feather="chevron-up" class="feather-chevron-up"></i></a>
            </li>
        </ul>
    </div>
    <form id="customer_form" action="<?php echo e(route('location.edit_customer',['id'=>Request()->segment(3)])); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="card">
            <div class="card-body">
                <div class="new-employee-field">
                    <div class="card-title-head">
                        <h6><span><i data-feather="info" class="feather-edit"></i></span>Customer Information</h6>
                    </div>
                    <div class="row mb-3">
                        <div class="col-lg-6 col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Customer</label>
                                <input type="text" name="customer_name" class="form-control" value="<?php echo e($customer->customer_name); ?>" autocomplete="off">
                                <?php if($errors->has('customer_name')): ?>
                                <small class="text-danger"><?php echo e($errors->first('customer_name')); ?></small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="text" name="customer_email" class="form-control" value="<?php echo e($customer->customer_email); ?>" autocomplete="off">
                                <?php if($errors->has('customer_email')): ?>
                                <small class="text-danger"><?php echo e($errors->first('customer_email')); ?></small>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Phone</label>
                                <input type="text" name="customer_phone" class="form-control" value="<?php echo e($customer->customer_phone); ?>" autocomplete="off">
                                
                            </div>
                        </div>
                        
                        
                        
                    </div>
                </div>
            </div>
        </div>
        <div class="text-end mb-3">
            <button type="submit" name="submit" class="btn btn-submit" value="submit">Save</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('location.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u391328125/domains/hellodev.site/public_html/POS/resources/views/location/customer/edit_customer.blade.php ENDPATH**/ ?>